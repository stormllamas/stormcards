API Reference
=============


qrcode.image
------------

.. automodule:: qr_code.qrcode.image
   :members:


qrcode.maker
-------

.. automodule:: qr_code.qrcode.maker
   :members:


qrcode.serve
-------

.. automodule:: qr_code.qrcode.serve
   :members:


qrcode.utils
-------

.. automodule:: qr_code.qrcode.utils
   :members:


templatetags.qr_code
--------------------

.. automodule:: qr_code.templatetags.qr_code
   :members:


tests
-----

.. automodule:: qr_code.tests
   :members:
