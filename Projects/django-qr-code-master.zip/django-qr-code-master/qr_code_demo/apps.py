from django.apps import AppConfig


class QRCodeDemoConfig(AppConfig):
    name = 'qr_code_demo'
    verbose_name = 'Demo of Django QR Code'
